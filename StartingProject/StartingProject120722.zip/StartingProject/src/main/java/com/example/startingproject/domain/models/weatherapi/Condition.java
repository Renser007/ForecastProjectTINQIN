package com.example.startingproject.domain.models.weatherapi;

import lombok.*;

/*@Builder
@Getter
@Setter(AccessLevel.public)
@ToString*/
public class Condition {

    public String text;
    public String icon;
    public int code;
}
