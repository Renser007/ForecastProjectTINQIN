package com.example.startingproject.domain.models.weatherapi;

import lombok.*;

/*@Builder
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor*/
public class ApiWeather {

    public Location location;
    public Current current;
}
