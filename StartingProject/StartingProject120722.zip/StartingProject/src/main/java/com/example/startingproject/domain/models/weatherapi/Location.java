package com.example.startingproject.domain.models.weatherapi;

import lombok.*;

/*@Builder
@Getter
@Setter(AccessLevel.public)
@ToString*/
public class Location {

    public String name;
    public String region;
    public String country;
    public double lat;
    public double lon;
    public String tz_id;
    public int localtime_epoch;
    public String localtime;
}
